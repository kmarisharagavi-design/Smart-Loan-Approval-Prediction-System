<?php
session_start();
include 'db.php';

// Admin login check
if(!isset($_SESSION['admin_id'])){
    header("Location: admin_login.php");
    exit();
}

// Approve / Reject action
if(isset($_GET['action']) && isset($_GET['id'])){
    $loan_id = intval($_GET['id']);
    $action = $_GET['action'];

    if($action == "approve"){
        $conn->query("UPDATE loan_requests SET status='Approved' WHERE id=$loan_id");
    } elseif($action == "reject"){
        $conn->query("UPDATE loan_requests SET status='Rejected' WHERE id=$loan_id");
    }
}

// Fetch all loan requests
$loans = $conn->query("SELECT * FROM loan_requests ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Panel</title>
    <style>
        body { font-family: Arial, sans-serif; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: center; }
        th { background-color: #f2f2f2; }
        a { text-decoration: none; }
        .logout { margin-top: 20px; display: block; text-align: center; }
    </style>
</head>
<body>

<h2>Admin Panel - Loan Requests</h2>

<!-- Link to Dashboard -->
<p><a href="admin_dashboard.php">📊 Go to admin Dashboard</a></p>

<table>
<tr>
    <th>Name</th>
    <th>Employment</th>
    <th>Age</th>
    <th>Applicant Income</th>
    <th>Co-Applicant Income</th>
    <th>Loan Amount</th>
    <th>Status</th>
    <th>Prediction Score</th>
    <th>Documents</th>
    <th>Action</th>
</tr>

<?php
if($loans->num_rows > 0){
    while($row = $loans->fetch_assoc()){
        echo "<tr>
            <td>".$row['name']."</td>
            <td>".$row['employment_type']."</td>
            <td>".$row['age']."</td>
            <td>".$row['applicant_income']."</td>
            <td>".$row['coapplicant_income']."</td>
            <td>".$row['loan_amount']."</td>
            <td>".$row['status']."</td>
            <td>".$row['prediction_score']."</td>
            <td>";

        // Documents clickable links
        if(!empty($row['photo'])){
            echo "<a href='uploads/".$row['photo']."' target='_blank'>Photo</a><br>";
        }
        if(!empty($row['income_proof'])){
            echo "<a href='uploads/".$row['income_proof']."' target='_blank'>Income Proof</a><br>";
        }
        if(!empty($row['id_proof'])){
            echo "<a href='uploads/".$row['id_proof']."' target='_blank'>ID Proof</a>";
        }

        echo "</td>
            <td>
                <a href='admin_panel.php?action=approve&id=".$row['id']."'>✅ Approve</a> | 
                <a href='admin_panel.php?action=reject&id=".$row['id']."'>❌ Reject</a>
            </td>
        </tr>";
    }
}else{
    echo "<tr><td colspan='10'>No Loan Requests Found</td></tr>";
}
?>
</table>

<!-- Logout link at bottom -->
<p class="logout"><a href="logout.php">🚪 Logout</a></p>

</body>
</html>
