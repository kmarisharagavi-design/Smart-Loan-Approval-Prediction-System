<?php
session_start();
include 'db.php';

if(!isset($_GET['loan_id'])){
    echo "Invalid access!";
    exit();
}

$loan_id = intval($_GET['loan_id']);
$row = $conn->query("SELECT * FROM loan_requests WHERE id='$loan_id'")->fetch_assoc();
if(!$row){
    echo "Loan not found!";
    exit();
}

// Prediction logic
$status = "Pending";

// Student rule
if($row['employment_type'] == "Student"){
    if($row['age'] < 21 || $row['age'] > 25 || $row['coapplicant_income'] < 50000){
        $status = "Rejected";
    } else {
        $status = "Approved";
    }
}
// Unemployed rule
elseif($row['employment_type'] == "Unemployed"){
    $status = "Rejected";
}
// Salaried rule
elseif($row['employment_type'] == "Salaried"){
    if($row['applicant_income'] >= 30000 && $row['loan_amount'] >= 200000 && $row['loan_amount'] <= 1000000 && $row['age'] >= 30){
        $status = "Approved";
    } else {
        $status = "Rejected";
    }
}

$prob = $status=="Approved"?1:0;
$conn->query("UPDATE loan_requests SET status='$status', prediction_score='$prob' WHERE id='$loan_id'");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Prediction Result</title>
    <meta http-equiv="refresh" content="3;url=document_upload.php?loan_id=<?php echo $loan_id; ?>">
    <style>
        body {
            margin: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: linear-gradient(135deg, #74ebd5, #9face6); /* background gradient */
            font-family: Arial, sans-serif;
        }
        .container {
            background: #fff;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.2);
            text-align: center;
            width: 400px;
        }
        h2 {
            margin-bottom: 20px;
            color: #333;
        }
        .status {
            font-size: 22px;
            font-weight: bold;
            margin: 15px 0;
        }
        .approved {
            color: #28a745; /* green */
        }
        .rejected {
            color: #dc3545; /* red */
        }
        p {
            margin-top: 10px;
            color: #555;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Loan Prediction Completed ✅</h2>
        <p class="status <?php echo strtolower($status); ?>">
            Status: <?php echo $status; ?>
        </p>
        <p>Redirecting to <b>Document Upload</b> page...</p>
    </div>
</body>
</html>
