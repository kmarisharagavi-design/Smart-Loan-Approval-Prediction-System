<?php
session_start();
include 'db.php'; // database connection

if(isset($_POST['login'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Check if email exists
    $sql = "SELECT * FROM user WHERE email='$email'";
    $result = $conn->query($sql);

    if($result->num_rows > 0){
        $row = $result->fetch_assoc();

        // Verify password
        if(password_verify($password, $row['password'])){
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['name'] = $row['name'];
            header("Location:loan_form.php"); // Redirect to dashboard
            exit();
        } else {
            $error = "❌ Invalid Password!";
        }
    } else {
        $error = "❌ User not found!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Login</title>
    <style>
        body {
            margin: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #ff9a9e, #fad0c4); /* Different gradient for login */
        }

        .login-box {
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.3);
            width: 350px;
            text-align: center;
        }

        .login-box h2 {
            margin-bottom: 20px;
            color: #ff6f61;
        }

        .login-box input {
            width: 90%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 6px;
            border: 1px solid #ccc;
            font-size: 16px;
        }

        .login-box button {
            width: 95%;
            padding: 12px;
            margin-top: 10px;
            border: none;
            border-radius: 6px;
            background-color: #ff6f61;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
        }

        .login-box button:hover {
            background-color: #e55b50;
        }

        .login-box p {
            margin-top: 15px;
        }

        .error { color: red; }

        .login-box a {
            color: #ff6f61;
            text-decoration: none;
        }
        .login-box a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="login-box">
        <h2>Login Page</h2>

        <?php
        if(isset($error)) echo "<p class='error'>$error</p>";
        ?>

        <form method="POST">
            <input type="email" name="email" placeholder="Enter Email" required><br>
            <input type="password" name="password" placeholder="Enter Password" required><br>
            <button type="submit" name="login">Login</button>
        </form>

        <p>Don't have an account? <a href="signup.php">Signup Here</a></p>
    </div>
</body>
</html>
