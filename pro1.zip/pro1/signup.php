<?php
include 'db.php'; // Database connection

if(isset($_POST['signup'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    // Check if email already exists
    $check = "SELECT * FROM user WHERE email='$email'";
    $result = $conn->query($check);

    if($result->num_rows > 0){
        $error = "❌ Email already registered!";
    } else {
        $sql = "INSERT INTO user (name,email,password) VALUES ('$name','$email','$password')";
        if($conn->query($sql) === TRUE){
            $success = "✅ Signup Successful! <a href='login.php'>Login Now</a>";
        } else {
            $error = "❌ Error: ".$conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Signup</title>
    <style>
        body {
            margin: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #6dd5fa, #2980b9);
        }

        .signup-box {
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.3);
            width: 350px;
            text-align: center;
        }

        .signup-box h2 {
            margin-bottom: 20px;
            color: #2980b9;
        }

        .signup-box input {
            width: 90%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 6px;
            border: 1px solid #ccc;
            font-size: 16px;
        }

        .signup-box button {
            width: 95%;
            padding: 12px;
            margin-top: 10px;
            border: none;
            border-radius: 6px;
            background-color: #2980b9;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
        }

        .signup-box button:hover {
            background-color: #1a5276;
        }

        .signup-box p {
            margin-top: 15px;
        }

        .error { color: red; }
        .success { color: green; }

        .signup-box a {
            color: #2980b9;
            text-decoration: none;
        }
        .signup-box a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="signup-box">
        <h2>Signup Page</h2>

        <?php
        if(isset($error)) echo "<p class='error'>$error</p>";
        if(isset($success)) echo "<p class='success'>$success</p>";
        ?>

        <form method="POST">
            <input type="text" name="name" placeholder="Enter Name" required><br>
            <input type="email" name="email" placeholder="Enter Email" required><br>
            <input type="password" name="password" placeholder="Enter Password" required><br>
            <button type="submit" name="signup">Signup</button>
        </form>

        <p>Already have an account? <a href="login.php">Login Here</a></p>
    </div>
</body>
</html>
