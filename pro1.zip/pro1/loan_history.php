<?php
session_start();
include 'db.php';
if(!isset($_SESSION['user_id'])) header("Location: login.php");

$loans = $conn->query("SELECT * FROM loan_requests WHERE name='".$_SESSION['name']."' ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html>
<head><title>Loan History</title></head>
<body>
<h2>Your Loan History</h2>
<table border="1" cellpadding="5">
<tr>
<th>Employment</th><th>Age</th><th>Applicant Income</th><th>Co-Applicant Income</th>
<th>Loan Amount</th><th>Status</th><th>Score</th><th>Documents</th>
</tr>
<?php
if($loans->num_rows>0){
    while($row=$loans->fetch_assoc()){
        echo "<tr>
            <td>{$row['name']}</td>
            <td>{$row['employment_type']}</td>
            <td>{$row['age']}</td>
            <td>{$row['applicant_income']}</td>
            <td>{$row['coapplicant_income']}</td>
            <td>{$row['loan_amount']}</td>
            <td>{$row['status']}</td>
            <td>".round($row['prediction_score'],2)."</td>
            <td>".($row['photo']?"Uploaded":"Pending")."</td>
        </tr>";
    }
}else{
    echo "<tr><td colspan='8'>No loans found</td></tr>";
}
?>
</table>
<p><a href="loan_form.php">Apply New Loan</a> | <a href="logout.php">Logout</a></p>
</body>
</html>
