<?php
session_start();
include 'db.php';

if(!isset($_GET['loan_id'])){
    echo "Loan ID missing!";
    exit();
}
$loan_id = intval($_GET['loan_id']);
$row = $conn->query("SELECT * FROM loan_requests WHERE id='$loan_id'")->fetch_assoc();
if(!$row){
    echo "Loan not found!";
    exit();
}

$errors = [];
$success = "";

if(isset($_POST['upload'])){
    $account_no = $_POST['account_no'];
    $upload_dir = "uploads/";
    $allowed_types = ['image/jpeg','image/png','application/pdf'];

    if(!is_dir($upload_dir)){
        mkdir($upload_dir,0777,true);
    }

    if(isset($_FILES['photo']) && $_FILES['photo']['error']==0){
        if(in_array($_FILES['photo']['type'],$allowed_types)){
            $photo_name = time().'_'.basename($_FILES['photo']['name']);
            if(!move_uploaded_file($_FILES['photo']['tmp_name'],$upload_dir.$photo_name)){
                $errors[]="Failed to upload passport photo!";
            }
        } else $errors[]="Invalid passport photo type!";
    } else $errors[]="Upload passport photo";

    if(isset($_FILES['income_proof']) && $_FILES['income_proof']['error']==0){
        if(in_array($_FILES['income_proof']['type'],$allowed_types)){
            $income_name = time().'_'.basename($_FILES['income_proof']['name']);
            if(!move_uploaded_file($_FILES['income_proof']['tmp_name'],$upload_dir.$income_name)){
                $errors[]="Failed to upload income proof!";
            }
        } else $errors[]="Invalid income proof type!";
    } else $errors[]="Upload income proof";

    if(isset($_FILES['id_proof']) && $_FILES['id_proof']['error']==0){
        if(in_array($_FILES['id_proof']['type'],$allowed_types)){
            $id_name = time().'_'.basename($_FILES['id_proof']['name']);
            if(!move_uploaded_file($_FILES['id_proof']['tmp_name'],$upload_dir.$id_name)){
                $errors[]="Failed to upload ID proof!";
            }
        } else $errors[]="Invalid ID proof type!";
    } else $errors[]="Upload ID proof";

    if(empty($errors)){
        $conn->query("UPDATE loan_requests SET 
            account_no='$account_no',
            photo='$photo_name',
            income_proof='$income_name',
            id_proof='$id_name'
            WHERE id='$loan_id'");
        $success = "✅ Documents uploaded successfully!";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Upload Documents</title>
    <style>
        body {
            margin: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: linear-gradient(135deg, #f093fb, #f5576c);
            font-family: Arial, sans-serif;
        }
        .container {
            background: #fff;
            padding: 30px 40px;
            border-radius: 15px;
            box-shadow: 0px 8px 20px rgba(0,0,0,0.2);
            width: 400px;
            text-align: center;
        }
        h2 {
            margin-bottom: 20px;
            color: #333;
        }
        form {
            text-align: left;
        }
        label {
            display: block;
            margin: 10px 0 5px;
            font-weight: bold;
            color: #444;
        }
        input[type="text"], input[type="file"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #bbb;
            border-radius: 8px;
        }
        button {
            margin-top: 15px;
            padding: 10px;
            width: 100%;
            background: #28a745;
            border: none;
            border-radius: 8px;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
        }
        button:hover {
            background: #218838;
        }
        .msg {
            margin: 10px 0;
            font-weight: bold;
        }
        .error { color: red; }
        .success { color: green; }
        a {
            text-decoration: none;
            color: #007bff;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Upload Documents</h2>

        <?php
        if(!empty($errors)){
            foreach($errors as $e) echo "<p class='msg error'>$e</p>";
        }
        if($success!="") echo "<p class='msg success'>$success</p>";
        ?>

        <form method="POST" enctype="multipart/form-data">
            <label>Account No:</label>
            <input type="text" name="account_no" required>

            <label>Passport Photo:</label>
            <input type="file" name="photo" required>

            <label>Income Proof:</label>
            <input type="file" name="income_proof" required>

            <label>ID Proof:</label>
            <input type="file" name="id_proof" required>

            <button type="submit" name="upload">Upload Documents</button>
        </form>

        <p><a href="loan_history.php">Go to Loan History</a></p>
    </div>
</body>
</html>
