<?php
session_start();
include 'db.php';

if(!isset($_SESSION['admin_id'])){
    header("Location: admin_login.php");
    exit();
}

// Total loans
$totalLoans = $conn->query("SELECT COUNT(*) as c FROM loan_requests")->fetch_assoc()['c'];
$approved = $conn->query("SELECT COUNT(*) as c FROM loan_requests WHERE status='Approved'")->fetch_assoc()['c'];
$rejected = $conn->query("SELECT COUNT(*) as c FROM loan_requests WHERE status='Rejected'")->fetch_assoc()['c'];
$pending  = $conn->query("SELECT COUNT(*) as c FROM loan_requests WHERE status='Pending'")->fetch_assoc()['c'];

// Employment type approval counts
$employment_types = ['Student','Salaried','Unemployed'];
$employment_data = [];
foreach($employment_types as $type){
    $approved_count = $conn->query("SELECT COUNT(*) as c FROM loan_requests WHERE employment_type='$type' AND status='Approved'")->fetch_assoc()['c'];
    $rejected_count = $conn->query("SELECT COUNT(*) as c FROM loan_requests WHERE employment_type='$type' AND status='Rejected'")->fetch_assoc()['c'];
    $employment_data[$type] = ['Approved'=>$approved_count,'Rejected'=>$rejected_count];
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { font-family: Arial, sans-serif; }
        .chart-container { width: 400px; margin: 20px; display: inline-block; }
    </style>
</head>
<body>
<h1>📊 Admin Dashboard</h1>
<p>Total Loans: <b><?php echo $totalLoans; ?></b> | Approved: <b><?php echo $approved; ?></b> | Rejected: <b><?php echo $rejected; ?></b> | Pending: <b><?php echo $pending; ?></b></p>

<div class="chart-container">
    <canvas id="statusChart"></canvas>
</div>

<div class="chart-container">
    <canvas id="employmentChart"></canvas>
</div>

<p><a href="admin_panel.php">⬅ Back to Admin Panel</a> | <a href="admin_logout.php">Logout</a></p>

<script>
// Status Pie Chart
const ctx1 = document.getElementById('statusChart').getContext('2d');
new Chart(ctx1, {
    type: 'pie',
    data: {
        labels: ['Approved','Rejected','Pending'],
        datasets: [{
            data: [<?php echo "$approved,$rejected,$pending"; ?>],
            backgroundColor: ['#4CAF50','#F44336','#FFC107']
        }]
    },
    options: {
        plugins: { title: { display: true, text: 'Loan Status Overview' } }
    }
});

// Employment type Approval/Rejection Chart
const ctx2 = document.getElementById('employmentChart').getContext('2d');
new Chart(ctx2, {
    type: 'bar',
    data: {
        labels: <?php echo json_encode(array_keys($employment_data)); ?>,
        datasets: [
            {
                label: 'Approved',
                data: <?php echo json_encode(array_column($employment_data,'Approved')); ?>,
                backgroundColor: '#4CAF50'
            },
            {
                label: 'Rejected',
                data: <?php echo json_encode(array_column($employment_data,'Rejected')); ?>,
                backgroundColor: '#F44336'
            }
        ]
    },
    options: {
        plugins: { title: { display: true, text: 'Approval vs Rejection by Employment Type' } },
        scales: { y: { beginAtZero: true } }
    }
});
</script>
</body>
</html>
