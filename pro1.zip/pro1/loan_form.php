<?php
session_start();
include 'db.php';

if(!isset($_SESSION['user_name'])) {
    $_SESSION['user_name'] = "user_name"; // Replace with actual login session
}

if(isset($_POST['apply'])){
    $name = $_SESSION['name'];
    $employment = $_POST['employment'];
    $age = intval($_POST['age']);
    $app_income = floatval($_POST['applicant_income']);
    $co_income = floatval($_POST['coapplicant_income']);
    $loan_amount = floatval($_POST['loan_amount']);

    $sql = "INSERT INTO loan_requests 
            (name, employment_type, age, applicant_income, coapplicant_income, loan_amount) 
            VALUES 
            ('$name','$employment','$age','$app_income','$co_income','$loan_amount')";
    if($conn->query($sql) === TRUE){
        $loan_id = $conn->insert_id;
        header("Location: predict.php?loan_id=$loan_id");
        exit();
    } else {
        echo "Error: ".$conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Loan Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(to right, #f8f9fa, #dfe9f3);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .form-container {
            background-color: #ffffff;
            padding: 30px 40px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            width: 400px;
        }
        h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #333;
        }
        input, select, button {
            width: 100%;
            padding: 10px 12px;
            margin-bottom: 15px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 15px;
        }
        button {
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        label {
            font-weight: bold;
            margin-bottom: 5px;
            display: block;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Loan Application Form</h2>
        <form method="POST">
            <label>Employment Type:</label>
            <select name="employment" required>
                <option value="">Select</option>
                <option value="Student">Student</option>
                <option value="Salaried">Salaried</option>
                <option value="Unemployed">Unemployed</option>
            </select>

            <label>Age:</label>
            <input type="number" name="age" required>

            <label>Applicant Income:</label>
            <input type="number" name="applicant_income" step="0.01">

            <label>Co-Applicant Income:</label>
            <input type="number" name="coapplicant_income" step="0.01">

            <label>Loan Amount:</label>
            <input type="number" name="loan_amount" step="0.01" required>

            <button type="submit" name="apply">Submit & Predict</button>
        </form>
    </div>
</body>
</html>
