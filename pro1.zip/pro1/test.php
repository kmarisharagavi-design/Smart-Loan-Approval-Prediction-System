<!DOCTYPE html>
<html>
<head>
    <title>Test Gradient</title>
    <style>
        body {
            margin: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: linear-gradient(135deg, #6dd5fa, #2980b9);
            font-family: Arial, sans-serif;
        }
        .box {
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.3);
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="box">
        <h2>Test Box</h2>
        <p>Background should be gradient and box centered ✅</p>
    </div>
</body>
</html>
